# shop > 2022-10-07 3:46pm
https://universe.roboflow.com/ajit-kumar-iorae/shop-xudgd

Provided by a Roboflow user
License: CC BY 4.0

